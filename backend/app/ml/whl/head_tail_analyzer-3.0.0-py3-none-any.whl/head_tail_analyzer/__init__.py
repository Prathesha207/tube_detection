"""head_tail_analyzer - count tube heads/tails in video, measure width, find the bigger tube.

    from head_tail_analyzer import HeadTailAnalyzer
    analyzer = HeadTailAnalyzer("config.yaml")
    analyzer.load_model()
    for result in analyzer.process_video("video.mp4"):
        ...

Command line:  hta  |  hta-frames  |  hta-api   (hta-api needs: pip install head-tail-analyzer[api])
"""
__version__ = "3.0.0"

from .main import HeadTailAnalyzer                                        # noqa: F401
from .run_video_frames import (AnalyzerError, ModelManager, MODELS,      # noqa: F401
                               load_model, unload_model, is_model_loaded)
